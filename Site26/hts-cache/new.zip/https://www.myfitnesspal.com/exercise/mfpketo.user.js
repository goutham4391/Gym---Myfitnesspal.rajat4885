<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
  <title>Page not found</title>
  <meta http-equiv="content-type" content="text/html; charset=ISO-8859-1" />
	<meta name="description" content="" />
  <meta name="keywords" content="" />
	<meta name="revisit-after" content="1 day" />
  <meta  name="robots" content="index,follow" />
  <link href="/assets/style.css" media="all" rel="stylesheet" type="text/css" />

  <script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-94924-2']);
    _gaq.push(['_trackPageview', '/404.html']);
    (function() {
      var ga = document.createElement('script'); ga.type = 'text/javascript'; ga.async = true;
      ga.src = ('https:' == document.location.protocol ? 'https://ssl' : 'http://www') + '.google-analytics.com/ga.js';
      var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(ga, s);
    })();
  </script>
</head>
<body id="maintenance">
<div id="container">

	<div id="header_no_tab">
	<div id="logo_no_tab">
		<img src="/assets/logo.gif" alt="MyFitnessPal" />
	</div>
	</div>

  <div id="content">
	<br />
	<br />
	<div id="site_down">
	<h1>Page not found</h1>
		<p class="normal">Sorry, but the page you requested was not found.  Please check the URL and try again.</p>
	</div>
	</div>

	<div id="pagebot">
	<div id="footer">
	<center>
	<i>Copyright 2006-16 MyFitnessPal Inc. All rights reserved.</i>
	</center>
	</div>
	</div>
</div>
<script type="text/JavaScript">
<!--
setTimeout("location.href = 'http://www.myfitnesspal.com';",10000);
-->
</script>
</body>
</html>
